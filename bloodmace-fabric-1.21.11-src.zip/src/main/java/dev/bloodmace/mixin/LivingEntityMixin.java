package dev.bloodmace.mixin;

import dev.bloodmace.BloodManager;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "handleEntityEvent", at = @At("HEAD"))
    private void bloodmace$onEvent(byte status, CallbackInfo ci) {
        if (status != 3) return; // 3 = death
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level() instanceof ClientLevel level) {
            BloodManager.onDeath(level, self);
        }
    }
}
