package dev.bloodmace;

import com.mojang.math.Transformation;
import dev.bloodmace.mixin.BlockDisplayAccessor;
import dev.bloodmace.mixin.DisplayAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.*;

/**
 * Blood = thin voxel "decals" made of client-only BlockDisplay entities.
 * They are never sent to / known by the server.
 */
public final class BloodManager {
    // ===== SETTINGS =====
    private static final float PX = 1f / 16f;
    private static final int MAX_ALIVE = 3500;              // max blood pieces at once
    private static final long LIFETIME = 20L * 240;         // 4 minutes
    private static final int PER_TICK = 120;                // spawn budget per tick
    private static final double HIT_RANGE = 4.5;
    private static final double HEAVY_RANGE = 7.0;
    private static final double DEATH_RANGE = 10.0;         // death burst radius, blocks
    private static final int HIT_RAYS = 10, HEAVY_RAYS = 22, DEATH_RAYS = 90;
    private static final boolean ALL_DEATHS = false;        // true = blood on any death, not only after mace
    private static final long MACE_DEATH_WINDOW = 40;       // ticks after mace hit that count as mace kill
    // ====================

    private static final float OFF = 0.05f;
    private static final float THICK = 0.003f;
    private static final Random RNG = new Random();

    private static final BlockState[] BLOOD = {
            Blocks.RED_CONCRETE.defaultBlockState(),
            Blocks.RED_CONCRETE.defaultBlockState(),
            Blocks.NETHER_WART_BLOCK.defaultBlockState(),
            Blocks.RED_NETHER_BRICKS.defaultBlockState(),
            Blocks.RED_NETHER_BRICKS.defaultBlockState(),
    };

    private record Box(long when, Vec3 pos, Direction face, float du, float dv,
                       float w, float h, float layer, int state) {}
    private record Alive(Display.BlockDisplay entity, long expire) {}
    private record Hit(long tick, Vec3 bias) {}

    private static final PriorityQueue<Box> PENDING =
            new PriorityQueue<>(Comparator.comparingLong(Box::when));
    private static final ArrayDeque<Alive> ALIVE = new ArrayDeque<>();
    private static final Map<Integer, Hit> LAST_MACE = new HashMap<>();
    private static long now = 0;
    private static int nextId = -2_000_000; // negative ids never clash with server entities

    private BloodManager() {}

    public static void clear() {
        PENDING.clear();
        ALIVE.clear();
        LAST_MACE.clear();
    }

    // ---------- events ----------

    public static void onDamage(ClientLevel level, Entity victim, Entity attacker) {
        if (!(attacker instanceof LivingEntity la) || !la.getMainHandItem().is(Items.MACE)) return;
        if (!(victim instanceof LivingEntity) || victim instanceof ArmorStand) return;

        Vec3 bias = victim.position().subtract(attacker.position());
        bias = new Vec3(bias.x, 0, bias.z);
        bias = bias.lengthSqr() > 1.0E-4 ? bias.normalize() : Vec3.ZERO;
        LAST_MACE.put(victim.getId(), new Hit(now, bias));
        if (LAST_MACE.size() > 256) LAST_MACE.entrySet().removeIf(e -> now - e.getValue().tick > 200);

        boolean heavy = la.getDeltaMovement().y < -0.4; // smash attack
        Vec3 origin = victim.position().add(0, victim.getBbHeight() * 0.6, 0);
        burst(level, origin, bias, heavy ? HEAVY_RAYS : HIT_RAYS,
                heavy ? HEAVY_RANGE : HIT_RANGE, now, victim);
    }

    public static void onDeath(ClientLevel level, LivingEntity victim) {
        if (victim instanceof ArmorStand) return;
        Hit hit = LAST_MACE.remove(victim.getId());
        boolean mace = hit != null && now - hit.tick <= MACE_DEATH_WINDOW;
        if (!mace && !ALL_DEATHS) return;

        Vec3 bias = hit != null ? hit.bias : Vec3.ZERO;
        Vec3 origin = victim.position().add(0, victim.getBbHeight() * 0.55, 0);
        burst(level, origin, bias, DEATH_RAYS, DEATH_RANGE, now, victim);
        pool(level, victim.position(), now + 2, victim);
    }

    // ---------- generation ----------

    private static Vec3 randomDir() {
        Vec3 v = new Vec3(RNG.nextGaussian(), RNG.nextGaussian() * 0.8, RNG.nextGaussian());
        return v.lengthSqr() < 1.0E-6 ? new Vec3(0, 1, 0) : v.normalize();
    }

    private static void burst(ClientLevel level, Vec3 origin, Vec3 bias, int rays,
                              double range, long baseTick, Entity ignore) {
        for (int i = 0; i < rays; i++) {
            Vec3 dir = randomDir();
            if (bias.lengthSqr() > 0 && RNG.nextFloat() < 0.5f) {
                dir = dir.scale(0.6).add(bias).normalize();
            }
            double len = range * (0.35 + 0.65 * RNG.nextDouble());
            Vec3 to = origin.add(dir.scale(len));
            BlockHitResult hit = level.clip(new ClipContext(origin, to,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, ignore));
            if (hit.getType() == HitResult.Type.MISS) continue;

            double d = origin.distanceTo(hit.getLocation());
            float radius = (float) Mth.clamp(0.5 - d * 0.04, 0.12, 0.5);
            long when = baseTick + (long) (d * 0.9); // blood "flies" outwards
            splat(hit.getLocation(), hit.getDirection(), radius, when);
        }
    }

    private static float snap(float v) {
        return Math.round(v / PX) * PX;
    }

    private static void splat(Vec3 hit, Direction face, float radius, long when) {
        Vec3 pos = hit.add(face.getStepX() * OFF, face.getStepY() * OFF, face.getStepZ() * OFF);
        int n = 3 + RNG.nextInt(5);
        for (int i = 0; i < n; i++) {
            float du = 0, dv = 0;
            int px;
            if (i == 0) {
                px = 2 + RNG.nextInt(3);
            } else {
                du = snap((float) RNG.nextGaussian() * radius * 0.55f);
                dv = snap((float) RNG.nextGaussian() * radius * 0.55f);
                px = 1 + RNG.nextInt(3);
            }
            float s = px * PX;
            PENDING.add(new Box(when, pos, face, du, dv, s, s, RNG.nextFloat() * 0.006f, RNG.nextInt(BLOOD.length)));
        }

        // drips running down walls
        if (face.getAxis() != Direction.Axis.Y && RNG.nextFloat() < 0.5f) {
            float len = (2 + RNG.nextInt(8)) * PX;
            boolean uVertical = face.getAxis() == Direction.Axis.X; // X face: u=Y ; Z face: v=Y
            float off = snap((float) RNG.nextGaussian() * radius * 0.4f);
            float w = uVertical ? len : PX;
            float h = uVertical ? PX : len;
            float du = uVertical ? -len / 2f : off;
            float dv = uVertical ? off : -len / 2f;
            PENDING.add(new Box(when + 3 + RNG.nextInt(6), pos, face, du, dv, w, h,
                    RNG.nextFloat() * 0.006f, RNG.nextInt(BLOOD.length)));
        }
    }

    private static void pool(ClientLevel level, Vec3 feet, long when, Entity ignore) {
        for (int i = 0; i < 55; i++) {
            double r = Math.abs(RNG.nextGaussian()) * 0.75;
            double a = RNG.nextDouble() * Math.PI * 2;
            double x = (Math.floor((feet.x + Math.cos(a) * r) * 16) + 0.5) / 16.0;
            double z = (Math.floor((feet.z + Math.sin(a) * r) * 16) + 0.5) / 16.0;
            Vec3 from = new Vec3(x, feet.y + 0.6, z);
            BlockHitResult hit = level.clip(new ClipContext(from, from.add(0, -1.6, 0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, ignore));
            if (hit.getType() == HitResult.Type.MISS || hit.getDirection() != Direction.UP) continue;
            int px = r < 0.35 ? 3 + RNG.nextInt(3) : 1 + RNG.nextInt(3);
            float s = px * PX;
            Vec3 pos = new Vec3(x, hit.getLocation().y + OFF, z);
            PENDING.add(new Box(when + (long) (r * 5), pos, Direction.UP, 0, 0, s, s,
                    RNG.nextFloat() * 0.006f, RNG.nextInt(BLOOD.length)));
        }
    }

    // ---------- spawning / lifecycle ----------

    private static void spawn(ClientLevel level, Box b) {
        int ax = b.face.getAxis().ordinal(); // X=0 Y=1 Z=2
        int u, v;
        switch (ax) {
            case 0 -> { u = 1; v = 2; }
            case 1 -> { u = 0; v = 2; }
            default -> { u = 0; v = 1; }
        }
        float[] scale = new float[3];
        float[] center = new float[3];
        scale[u] = b.w;
        scale[v] = b.h;
        scale[ax] = THICK;
        center[u] = b.du;
        center[v] = b.dv;
        center[ax] = b.face.getAxisDirection().getStep() * (-OFF + 0.002f + b.layer + THICK / 2f);

        Vector3f translation = new Vector3f(
                center[0] - scale[0] / 2f, center[1] - scale[1] / 2f, center[2] - scale[2] / 2f);

        Display.BlockDisplay e = new Display.BlockDisplay(EntityType.BLOCK_DISPLAY, level);
        e.setId(nextId--);
        e.setPos(b.pos.x, b.pos.y, b.pos.z);
        ((BlockDisplayAccessor) (Object) e).bloodmace$setBlockState(BLOOD[b.state]);
        ((DisplayAccessor) (Object) e).bloodmace$setTransformation(
                new Transformation(translation, null, new Vector3f(scale[0], scale[1], scale[2]), null));
        level.addEntity(e);
        ALIVE.addLast(new Alive(e, now + LIFETIME));
    }

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null) {
            if (!PENDING.isEmpty() || !ALIVE.isEmpty()) clear();
            return;
        }
        now++;

        int spawned = 0;
        while (!PENDING.isEmpty() && PENDING.peek().when <= now && spawned < PER_TICK) {
            spawn(level, PENDING.poll());
            spawned++;
        }

        while (!ALIVE.isEmpty()) {
            Alive a = ALIVE.peekFirst();
            boolean gone = a.entity.isRemoved() || a.entity.level() != level;
            if (gone) {
                ALIVE.pollFirst();
            } else if (now >= a.expire || ALIVE.size() > MAX_ALIVE) {
                ALIVE.pollFirst();
                a.entity.discard();
            } else {
                break;
            }
        }
    }
}
