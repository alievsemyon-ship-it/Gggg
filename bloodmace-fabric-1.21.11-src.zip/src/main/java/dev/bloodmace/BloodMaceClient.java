package dev.bloodmace;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public class BloodMaceClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(BloodManager::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> BloodManager.clear());
    }
}
