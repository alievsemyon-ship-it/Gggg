Mace Blood (client-only Fabric mod, Minecraft 1.21.11)

BUILD:
  1) Install JDK 21.
  2) In this folder run:  gradle wrapper --gradle-version 9.2.1   (once, if no gradlew)
  3) ./gradlew build   (Windows: gradlew.bat build)
  4) Jar: build/libs/bloodmace-1.0.0.jar -> put in .minecraft/mods (needs Fabric Loader + Fabric API)

Settings are constants at the top of src/main/java/dev/bloodmace/BloodManager.java
